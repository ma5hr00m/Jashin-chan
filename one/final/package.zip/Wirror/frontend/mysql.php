<?php
$host = "127.0.0.1";
$user = "alice";
$pass = "alice123!@#";
$dbname = "chest";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connect Error: " . $conn->connect_error);
}

?>